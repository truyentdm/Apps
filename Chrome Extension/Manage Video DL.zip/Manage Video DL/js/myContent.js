
	
	// function loadDoc() {
	//   var xhttp = new XMLHttpRequest();
	//   xhttp.onreadystatechange = function() {
	// 	if (this.readyState == 4 && this.status == 200) {
	// 	 //document.getElementById("demo").innerHTML = this.responseText;
	// 	 console.log("text")
	// 	}
	//   };
	//   xhttp.open("GET", "http://localhost:8888/ip_address", true);
	//   xhttp.send();
	// }
	
	// loadDoc();

	